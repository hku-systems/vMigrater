      include 'mpif.h'
c mpi data types
      integer dc_type
      common /mpistuff/ dc_type
